package mis.clases;

import archivos.pilas.ArrayPila;
import javax.swing.JOptionPane;

public class ClienteCorporativo{
    //Atributos
    private String RUC, razonsocial, nombre;
    private ArrayPila listacomp;

    //constructor con parámetros
    public ClienteCorporativo(String nombre,String RUC, String razonsocial) {
        this.RUC = RUC;
        this.nombre=nombre;
        this.razonsocial = razonsocial;
        this.listacomp=new ArrayPila();
    }

    //metodos getters
    public String getRUC() {
        return RUC;
    }

    public String getRazonsocial() {
        return razonsocial;
    }

    public ArrayPila getLista_comp() {
        return listacomp;
    }
    
    public void Apilarc(Comprobante c)
    {
        this.listacomp.Apilar(c);
    }        
    
    public float SumaGiros(){
        float sumagiro = 0;
        ArrayPila pilita = new ArrayPila();
        while(listacomp.estaVacia() != true){
            Comprobante comp = listacomp.Desapilar();
            pilita.Apilar(comp);
            if(comp.getTipo().equalsIgnoreCase("Giro")){
                sumagiro+= comp.getMonto();
            }
        }
        while(pilita.estaVacia() != true){
            Comprobante comp1=pilita.Desapilar();
            listacomp.Apilar(comp1);
        }
        return sumagiro;
    }
    
    public float SumaEncomienda(){
        float sumaenc = 0;
        ArrayPila pilita = new ArrayPila();
        while(listacomp.estaVacia() != true){
            Comprobante comp = listacomp.Desapilar();
            pilita.Apilar(comp);
            if(comp.getTipo().equalsIgnoreCase("Encomienda")){
                sumaenc+= comp.getMonto();
            }
        }
        while(pilita.estaVacia() != true){
            Comprobante comp1 = pilita.Desapilar();
            listacomp.Apilar(comp1);
        }
        return sumaenc;
    }
    
    public void Apilarcomprobante(Comprobante comp){
        if(listacomp.estaLlena() == false){
            listacomp.Apilar(comp);
        }
        else if(listacomp.estaVacia() == true){
            JOptionPane.showMessageDialog(null,"No hay comprobantes");
        }
    }
    
    public String DatosCliente(){
        String cadena = "\nNombre: " + this.nombre
                + "\nRUC: " + this.RUC
                + "\nRazon Social: " + this.razonsocial
                + "\nComprobante: " + listacomp.VerPila();
        return cadena;
    }

    public static void main(String[] args) {
        
        Comprobante com=new Comprobante("aaaa","bbbb","zzzzz",500);
        Comprobante com2=new Comprobante("ccccc","ddddd","eeeee",7000);
        ClienteCorporativo cl=new ClienteCorporativo("fff","hhh","iii");
        cl.Apilarcomprobante(com);
        cl.Apilarcomprobante(com2);
        System.out.println(cl.DatosCliente());
        
    }
  
}
