package mis.clases;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Comprobante {
    private String tipo, ciudadorigen, ciudaddestino, fecha;
    private float monto;

    public Comprobante(String tipo, String ciudadorigen, String ciudaddestino, float monto) {
        this.tipo = tipo;
        this.ciudadorigen = ciudadorigen;
        this.ciudaddestino = ciudaddestino;
        this.monto = monto;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCiudadorigen() {
        return ciudadorigen;
    }

    public void setCiudadorigen(String ciudadorigen) {
        this.ciudadorigen = ciudadorigen;
    }

    public String getCiudaddestino() {
        return ciudaddestino;
    }

    public void setCiudaddestino(String ciudaddestino) {
        this.ciudaddestino = ciudaddestino;
    }
    
    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }
    
    public static String FechaActual(){
        Date fecha =new Date();
        SimpleDateFormat formatofecha=new SimpleDateFormat("dd/MM/YYYY");
        return formatofecha.format(fecha);
    }
    
    public String verComprobante(){
        String cadena="\nTipo de Comprobante: " + tipo
                + "\nCiudad de Origen: " + this.ciudadorigen
                + "\nCiudad de Destino: " + this.ciudaddestino
                + "\nMonto: " + monto
                + "\nFecha de Emision: " + FechaActual()+"\n";
        return cadena;
    }
}
