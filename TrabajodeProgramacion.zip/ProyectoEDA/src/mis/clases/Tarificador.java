public class Tarificador {
    private static final String [] ciudades={"Lima", "Huacho", "Cañete", 
                                            "Barranca", "Chancay", 
                                            "Paramonga", "Huaral"};
    
    private  static final double [][] recorrido= {{0,    140.4, 154.6, 190.4, 74.6,  200.5, 75.1},							
                                                  {140.4, 0,	 292.4,	53.9,  68.4,  64.1,  75.4},
                                                  {154.6, 292.4, 0,     342.8, 227.0, 353.0, 226.5},	
						  {190.4, 53.9,	 342.8,	0,     116.8, 14.9,  125.4},		
                                                  {74.6,  68.4,	 227.0,	116.8, 0,     127.4, 11.5},		
                                                  {200.5, 64.1,	 353.0,	14.9,  127.4, 0,     135.5},				
                                                  {75.1,  75.4,	 226.5,	125.4, 11.5,  135.5, 0}};
    
    private static final int [][] ruta= {{0,0,1,0,1,0,0},
                                          {0,0,0,1,1,0,0},
                                          {1,0,0,0,0,0,0},
                                          {0,1,0,0,0,1,0},
                                          {1,1,0,0,0,0,1},
                                          {0,0,0,1,0,0,0},
                                          {0,0,0,0,1,0,0}};
    private String ciudadorigen, ciudaddestino;
    private static final double traficaxkm = 3;

    public Tarificador(String ciudadOrigen, String ciudadDestino) {
        this.ciudadorigen = ciudadOrigen;
        this.ciudaddestino = ciudadDestino;
    }   
    
    public int busqueda(String c){
    //busca un elemento y retorna su posicion
        int i;
        for(i=0;i<ciudades.length;i++)
        {
            if(c.equals(ciudades[i])) return i;
        }
        return -1;
    }
    
    public double[][] MatrizAdyacencia(){  
    //Retorna una matriz de adyacencia con las recorrido entre las rutas
        double [][] a = new double[ciudades.length][ciudades.length];
        for(int i=0; i<recorrido.length;i++)
        {
            for (int j = 0; j<recorrido[0].length; j++) {
                a[i][j]=recorrido[i][j]*ruta[i][j];
            }
        }
        return a;
    }
    
    public double [] SeleccionarRutaOptima(){
        int Origen = busqueda(ciudadorigen);
        int Destino = busqueda(ciudaddestino);
        double [] rutaoptima = new double[ciudades.length];
        double [][] tempTarifa = this.MatrizAdyacencia();
        //Algoritmo de seleccion de ruta   
        int i = Origen;
        while (i != Destino){
            double menor = 1000000000;
            int menorpos = 0;
            for (int j = 0; j<tempTarifa.length; j++) 
            {
                if(i == Origen && j == Destino)
                {
                    menorpos=j;
                    rutaoptima[i] = tempTarifa[i][j];
                    break;
                }
                if(tempTarifa[i][j] != 0 && tempTarifa[i][j] < menor)
                {
                    menorpos = j;
                    rutaoptima[i] = tempTarifa[i][j];
                }  
            }
            i = menorpos;
        }
        return rutaoptima;
    }
    
    public double CalcularDistanciaKm(){
        double suma = 0;
        double[]a = this.SeleccionarRutaOptima();
        for (int i = 0; i<a.length; i++) {
            suma+= a[i];
        }
        return suma;
    }
    
    public  double calcularTarifa() {
    //Algoritmo Kruskal    
        return this.CalcularDistanciaKm()*this.traficaxkm;
    }
    
    public static void main(String[] args) 
    {
        Tarificador t = new Tarificador("Lima", "Huacho");
        double tarifa = t.calcularTarifa();
        System.out.println("la tarifa es " + tarifa);
    }
}
