
package archivos.colas;

import javax.swing.JOptionPane;

public class ArrayCola <ClienteCorporativo> implements Cola<ClienteCorporativo> 
{
    private static final int TAM_MAX = 50;
    private int frente,fin;
    private ClienteCorporativo[] ccorp;

    public ArrayCola() {
        ccorp = (ClienteCorporativo[]) new Object[TAM_MAX];
        frente = -1;
        fin = -1;
    }

    public static int getTAM_MAX() {
        return TAM_MAX;
    }

    public int getFrente() {
        return frente;
    }

    public int getFin() {
        return fin;
    }

    public ClienteCorporativo[] getCcorp() {
        return ccorp;
    }
    
    public boolean estaVacia(){
        boolean estado = false;
        if(frente == -1 && fin == -1){
            estado = true;
        }
        return estado;
    }
    public boolean estaLlena(){
        boolean estado = false;
        if((frente == 0 && fin == TAM_MAX-1) || frente == fin+1){
         estado = true;   
        }
        return estado;
    }
    
    public ClienteCorporativo desencolar(){
        ClienteCorporativo cc = ccorp[frente];
        if(frente == fin){
            frente = -1;
            fin = -1;
        }
        else{
            if(frente == TAM_MAX){
                frente = 0;
            }
            else{
                frente++;
            }
        }
        return cc;
    }
    
    public void encolar(ClienteCorporativo cliente){
        if(estaLlena() == false){
            if(estaVacia() == true){
                frente = 0;
                fin=0;
            }
            else if(fin == TAM_MAX-1){
                fin=0;
            }
            else{
                fin++;
            }
            ccorp[fin] = cliente;
        }
        else{
            JOptionPane.showMessageDialog(null,"La Cola está Llena");
        }
    }
    
    public ClienteCorporativo frenteC(){
        return ccorp[frente];
    }
    
    public String MostrarDatosCola()
    {
        String cadena = "";
        ArrayCola<ClienteCorporativo> ccorp = new ArrayCola<>();
        while(estaVacia() == false){
            ClienteCorporativo cc = desencolar();
            cadena+=cc.toString() + "\n";
            ccorp.encolar(cc);
        }
        while(ccorp.estaVacia() == false){
            ClienteCorporativo cc1 = ccorp.desencolar();
            encolar(cc1);
        }
        return cadena;
    }
}
