package archivos.colas;
public interface Cola <ClienteCorporativo>{
    boolean estaVacia();
    boolean estaLlena();
    ClienteCorporativo desencolar();
    void encolar(ClienteCorporativo cliente);
    ClienteCorporativo frenteC();   
}
