package archivos.pilas;

import mis.clases.Comprobante;

public interface Pila {
    boolean estaVacia();
    boolean estaLlena();
    void Apilar(Comprobante comp);
    Comprobante Desapilar();
  
}
