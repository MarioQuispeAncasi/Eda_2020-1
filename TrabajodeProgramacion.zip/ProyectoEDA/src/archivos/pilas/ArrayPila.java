package archivos.pilas;

import mis.clases.Comprobante;

public class ArrayPila implements Pila 
{
    private static final int TAM_MAX = 50;
    private Comprobante[] c;
    private int cima;

    public ArrayPila() {
        c = new Comprobante[TAM_MAX];
        cima = -1;
    }

    public static int getTAM_MAX() {
        return TAM_MAX;
    }

    public Comprobante[] getC() {
        return c;
    }

    public int getCima() {
        return cima;
    }
    
    public boolean estaVacia(){
        boolean estado = false;
        if(cima == -1){
            estado = true;
        }
        return estado;
    }
    
    public boolean estaLlena(){
        boolean estado = false;
        if(cima == TAM_MAX){
            estado = true;
        }
        return estado;
    }
    
    public void Apilar(Comprobante comp){
         cima++;
        c[cima] = comp;
    }
    
    public Comprobante Desapilar(){
        Comprobante objeto = c[cima];
        cima--;
        return objeto;
    }
    
    public String VerPila(){
        String cadena = "";
        ArrayPila pilita = new ArrayPila();
        while(estaVacia() != true){
            Comprobante comp = Desapilar();
            cadena+=comp.verComprobante()+"\n";
            pilita.Apilar(comp);
        }
        while(pilita.estaVacia() != true){
            Comprobante comp1 = pilita.Desapilar();
            Apilar(comp1);
        }
        return cadena;
    }
}
