package miGestion;

import archivos.colas.ArrayCola;
import archivos.pilas.ArrayPila;
import mis.clases.ClienteCorporativo;
import mis.clases.Comprobante;

public class GestionMensajeria{
    //Atributos
    private float montoencomienda, montogiro;        
    private ArrayCola<ClienteCorporativo> ccorp;

    //Constructor sin parámetros
    public GestionMensajeria(){
        ccorp = new ArrayCola<ClienteCorporativo>(); 
    }

    //metodos getters
    public float getMontoencomienda() {
        return montoencomienda;
    }

    public float getMontogiro() {
        return montogiro;
    }

    public ArrayCola getColacc() {
        return ccorp;
    }
    
    //metodo para encolar clientes
    public void EncolarCliente(ClienteCorporativo cc){
            ccorp.encolar(cc);
    }
    
     public String calcularmontos(){
        float recaudaciongiro = 0, recaudacionenc = 0;
        ArrayCola<ClienteCorporativo> corp =new ArrayCola<>();
        while(ccorp.estaVacia() != true){
            ClienteCorporativo c1 = ccorp.desencolar();
            corp.encolar(c1);
            recaudacionenc+=c1.SumaEncomienda();
            recaudaciongiro+=c1.SumaGiros();
        }
        while(corp.estaVacia() != true){
            ClienteCorporativo c2 = corp.desencolar();
            ccorp.encolar(c2);
        }
        return ("\nMonto Total de Giros: " + recaudaciongiro
                + "\nMonto Total de Encomiendas: " + recaudacionenc);
    }
    
    public String vercola(){
        String cadena = "";
        ArrayCola<ClienteCorporativo> corp = new ArrayCola<>();
        while(ccorp.estaVacia() != true){
            ClienteCorporativo c1 = ccorp.desencolar();
            cadena+=c1.DatosCliente();
            corp.encolar(c1);
        }
        while(corp.estaVacia() != true){
            ClienteCorporativo c2 = corp.desencolar();
            ccorp.encolar(c2);
        } 
        return cadena;
    }

    public static void main(String[] args) {
        GestionMensajeria gm=new GestionMensajeria();
        Comprobante c=new Comprobante("aaaaa","bbbbb","cccc",1234);
        Comprobante c1=new Comprobante("dddd","eeee","hhhh",4000);
        ClienteCorporativo cc=new ClienteCorporativo("iiiii","1234567","ooooo");
        cc.Apilarcomprobante(c);
        cc.Apilarcomprobante(c1);
        gm.EncolarCliente(cc);
        System.out.println(gm.vercola());
    }  
}
