package archivos.pilas;

import java.util.ArrayList;
import mis.clases.Comprobante;

public class ArrayPila implements Pila{
    private int[] datos;
    int cima;
    private static final int TAM_MAX = 50;
    
    public ArrayPila(){
        datos = new int[TAM_MAX];
        cima = -1;
    }
    
    public boolean estaVacia(){
        boolean estado = (cima == -1);
        return estado;
    }
    
    public boolean estaLlena(){
        boolean estado = (cima + 1 == TAM_MAX);
        return estado;
    }
    
    public void apilar(Integer item){
        if(!this.estaLlena()){
            cima++;
            datos[cima] = item;
        }
    }
    
    public Integer desapilar(){
        Integer valor = null;
        if(!this.estaVacia()){
            valor = datos[cima];
            cima--;
        }
        return valor;
    }
    
    public void mostrarElementos(){
        for(int i = 0; i <= cima; i++){
            System.out.print(datos[i] + " -> ");
        }
        System.out.println("CIMA");
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*ArrayList<Comprobante> pila = new ArrayList<Comprobante>();
    //add
    public void Push(Comprobante s){
          
    pila.add(s);
        
    }
    //remover
    public void Pop(){
        if(!pila.isEmpty()){      
           pila.remove(pila.size()-1);
        }
    }
    
    public String Verpila(){
    String p="";
    for(int i=0;i<pila.size();i++)
        p+="Item "+ (i+1)+" "+pila.get(i)+"\n";
    return p;
    }

    public int Items(){
    return pila.size();
    }
    
    public void VaciarPila(){
        
        pila.clear();
        
    }
    public Comprobante Ultimo(){
    Comprobante h=null;
    if(pila.size()>0)
    h=pila.get(pila.size()-1);
    return h;
    }
    public Comprobante Primero(){
    
        Comprobante u=null;
        if(pila.size()>0)
        u=pila.get(0);
        return u;
        }
    
    public String empty(){
        String e="";
        
        if (pila.size()==0){
            e="si";
        }else{
        e="no";        
        }
        return e;
    }

    public Comprobante mcomprobantes(int i){
        Comprobante h;
        h = pila.get(i);
        return h;
    }

    public int Contador() {
               return pila.size();
    }*/

}
