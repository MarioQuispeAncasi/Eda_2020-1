package archivos.colas;

public class ArrayColas {
    
}
