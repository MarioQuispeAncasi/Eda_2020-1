package miGestion;

import archivos.colas.Cola;

public class GestionMensajeria implements Cola{
    //Atributos
    private Cola ClienteCorporativo;
    private double mrencomienda,mrgiro;
//Constructor sin parametros
    public GestionMensajeria() {
    }

//Metodos getters
    public Cola getClienteCorporativo() {
        return ClienteCorporativo;
    }

    public double getMrencomienda() {
        return mrencomienda;
    }

    public double getMrgiro() {
        return mrgiro;
    }
    
/*Metodo que se ocupe de encolar un objeto ClienteCorporativo alcanzado como
parámetro, donde incluya su pila de comprobantes.*/
 
    
/*Método redefinido toString ()   */
    public String VerInfo() {
        return "GestionMensajeria:" + 
                "\nClienteCorporativo:" + ClienteCorporativo + 
                "\nMonto de recaudación en encomiendas: " + mrencomienda + 
                "\nMonto de recaudación en giros: " + mrgiro;
    }
    
    
//Metodo reporte de recaudación
    
}
