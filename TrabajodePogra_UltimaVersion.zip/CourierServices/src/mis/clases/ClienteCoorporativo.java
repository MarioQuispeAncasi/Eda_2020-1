package mis.clases;

import archivos.pilas.ArrayPila;
public class ClienteCoorporativo {
    //Atributos
   private ArrayPila listacomprobante;
   private String razonsocial;
   private long RUC;
   //ArrayPila listacomprobante = new ArrayPila();

   //Constructor
    public ClienteCoorporativo(ArrayPila listacomprobante, String razonsocial, long RUC) {
        this.listacomprobante = listacomprobante;
        this.razonsocial = razonsocial;
        this.RUC = RUC;
    }

    //Metodo get
    public ArrayPila getListacomprobante() {
        return listacomprobante;
    }

    public String getRazonsocial() {
        return razonsocial;
    }

    public long getRUC() {
        return RUC;
    }
    
    //Método que permite apilar un comprobante al cliente corporativo
    public void apilarcom(Integer item){
        listacomprobante.apilar(item);
    }
   
}
