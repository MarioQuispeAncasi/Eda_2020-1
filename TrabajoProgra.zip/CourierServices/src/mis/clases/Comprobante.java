package mis.clases;

import archivos.colas.Cola;

public class Comprobante implements Cola{
  //Atributos
  private String ciudadorigen,ciudaddestino,fechaemision;
  private double monto;
    public Comprobante(double monto) {
        this.monto = monto;
    }
    
//Constructor
    public Comprobante(String ciudadorigen, String ciudaddestino, String fechaemision) {
        this.ciudadorigen = ciudadorigen;
        this.ciudaddestino = ciudaddestino;
        this.fechaemision = fechaemision;
    }
    
//Metodos getters y setters
    public String getCiudadorigen() {
        return ciudadorigen;
    }

    public void setCiudadorigen(String ciudadorigen) {
        this.ciudadorigen = ciudadorigen;
    }

    public String getCiudaddestino() {
        return ciudaddestino;
    }

    public void setCiudaddestino(String ciudaddestino) {
        this.ciudaddestino = ciudaddestino;
    }

    public String getFechaemision() {
        return fechaemision;
    }

    public void setFechaemision(String fechaemision) {
        this.fechaemision = fechaemision;
    }
//Metodo tostring
    public String VerInfo() {
        return "Comprobantes: " + 
                "\nCiudad de origen: " + ciudadorigen + 
                "\nCiudad de Destino: " + ciudaddestino + 
                "\nFecha de emisión: " + fechaemision + 
                "\nMonto: " + monto;
    }
 
}
