package archivos.colas;

public interface Cola {

}
