
package archivos.pilas;

import mis.clases.Comprobante;

public interface Pila {
    public void apilar(Integer item);
    public Integer desapilar();
    public boolean estaVacia();
}
